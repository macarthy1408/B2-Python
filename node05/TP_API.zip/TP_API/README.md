Pré-requis :
- Vous utiliserez l'API suivante :
  https://jsonplaceholder.typicode.com/

Sujet :

Ecrivez un script qui affichera les données d'un album, dans lequel vous ajouterez l'utilisateur et les photos qui lui sont associées.

La structure de l'objet final doit être la suivante :
{
  userId: 1,
  id: 1,
  title: 'quidem molestiae enim',
  user: {...},
  photos: [{...}, {...}, ...]
}

Vous devrez faire les 3 appels à l'API suivants :
  - récupérer l'album ayant l'id 1
  - récupérer l'utilisateur associé à l'album
  - récupérer les photos associées à l'album 