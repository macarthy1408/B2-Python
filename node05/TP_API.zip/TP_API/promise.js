const axios = require('axios')

const album = 'https://jsonplaceholder.typicode.com/albums/1'
const user = 'https://jsonplaceholder.typicode.com/users/1'
const photos = 'https://jsonplaceholder.typicode.com/photos/?albumId=1'

let utilisateur = {}
let promesse = []

const start = ()=>{
    promesse.push(
        axios.get(album)
    )

    promesse.push(
        axios.get(user)
    )

    promesse.push(
        axios.get(photos)
    )
    return Promise.all(promesse)
}

start()
    .then((response)=>{
        utilisateur['userId'] =  response[0].data.userId
        utilisateur['id'] = response[0].data.id
        utilisateur['title'] = response[0].data.title
        utilisateur['tite'] = response[0].data.title
        utilisateur['user'] = response[1].data
        utilisateur['photos'] = response[2].data
        console.log(utilisateur)
    })
    .catch(()=>{
        console.log('error')
    })